# Thirumalai Ananthalvan Website

A beautiful, respectful, and fully functional single-page devotional website dedicated to **Thirumalai Ananthalvan** (also known as Ananthalvar / Anpillai / Madhurakavidasa), the great disciple of Bhagavad Ramanuja and the gardener of Tirumala.

## What's Included

- `index.html` — Complete, self-contained website (uses Tailwind CSS via CDN + Font Awesome)
- `images/` folder containing 4 high-quality AI-generated devotional images:
  - `hero-tirumala.jpg`
  - `ananthalvan-idol.jpg`
  - `venkateswara-chin.jpg`
  - `nandavanam.jpg`

## How to Host / Upload

This website is extremely easy to host because it is a **single HTML file** + images folder.

### Recommended Free Hosting Options (easiest first):

1. **Netlify Drop** (Fastest - 30 seconds)
   - Go to: https://app.netlify.com/drop
   - Drag and drop the entire `ananthalvan-website` folder
   - Done! You get a free `.netlify.app` URL instantly.

2. **Vercel**
   - Go to https://vercel.com
   - Import or drag & drop the folder
   - Free hosting with custom domain support

3. **GitHub Pages** (Free & Permanent)
   - Create a new repository on GitHub
   - Upload the `index.html` and `images/` folder
   - Enable GitHub Pages in repository settings

4. **Any Web Host**
   - Upload the entire folder to your web hosting (cPanel, FTP, etc.)
   - Point your domain to the folder

## Important Notes

- The site works completely offline once downloaded.
- All images are locally referenced (`images/` folder).
- Tailwind CSS is loaded via CDN (no build step needed).
- The "Download PDF" button shows an alert pointing to your original document.

## Customization Tips

- Replace the images in the `images/` folder with your own photos of Tirumala/Ananthalvan idols.
- Edit the HTML directly to add more content, change colors, or add new sections.
- For a more advanced version, you can later convert it to a proper framework (Next.js, etc.).

---

**|| Śrīmate Rāmānujāya namaḥ ||**

Created with devotion for Srivaishnavas worldwide.